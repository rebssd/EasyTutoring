my_lambda = lambda do
  puts "lambda!!!"
end

my_lambda.call

puts my_lambda.class
puts my_lambda.inspect


