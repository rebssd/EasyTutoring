my_lambda_arrow = -> do
  puts "Arrow lambda!!!"
end

my_lambda_arrow.call

puts my_lambda_arrow.class
puts my_lambda_arrow.inspect


