hello_proc = proc do
  puts "Olá!"
end

hello_proc.call

puts hello_proc.class
puts hello_proc.inspect


