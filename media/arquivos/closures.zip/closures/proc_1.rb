hello_proc = Proc.new do
  puts "Olá!"
end

hello_proc.call

