class Backoffice::CategoriesController < BackofficeController
  #antes de começar utilize o metodo before_action nos metodos update e edit
  before_action :set_category, only: [:update,:edit]
  
  def index
  	@categories = Category.all
  end

  def new  	
    @category = Category.new
  end

  def edit
  end

  def update
    if @category.update(params_category)
      redirect_to backoffice_categories_path , notice: "A categoria (#{@category.description}) foi atualizada com sucesso!"
    else
      render :edit
    end
  end

  def create
    @category = Category.new(params_category)
    if  @category.save 
      redirect_to backoffice_categories_path , notice: "A categoria (#{@category.description}) foi cadastrada com sucesso!"
    else
      render :new
  	end
  end

  private

    def set_category
        #quando se usa o find é  utilizado somente para pesquisar pelo id 
        @category = Category.find(params[:id])
    end
    def params_category
      # solocitar a categoria e permitir que se utilize a descrição 
      params.require(:category).permit(:description)    
    end
end
